package jp.co.nri.s3batch.service;

public class Semc151dService extends BatchService {

    public Semc151dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc151dService started...name:[" + name + "]");
        disp("Semc151dService finished...name:[" + name + "]");
    }

}
