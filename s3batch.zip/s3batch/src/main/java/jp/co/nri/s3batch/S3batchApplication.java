package jp.co.nri.s3batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import jp.co.nri.s3batch.service.*;

@SpringBootApplication
public class S3batchApplication {

	public static void main(String[] args) {
		BatchService bs;
  	    String jobId;
		disp("main function: start...");
		if (args.length > 0) {
			jobId = args[0].toUpperCase();
		} else {
			jobId = "NO-JOB-DESIGNATED";
		}
		disp("job id:[" + jobId + "]...");
        try (ConfigurableApplicationContext ctx = SpringApplication.run(S3batchApplication.class, args)) {
			switch(jobId) {
				case "SEMC150D":
					bs = ctx.getBean(Semc150dService.class);
					bs.startProc();
					break;
				case "SEMC151D":
					bs = ctx.getBean(Semc151dService.class);
					bs.startProc();
					break;
				case "SEMC152D":
					bs = ctx.getBean(Semc152dService.class);
					bs.startProc();
					break;
				case "SEMC153D":
					bs = ctx.getBean(Semc153dService.class);
					bs.startProc();
					break;
				default:
					disp("Invalid Job-Id:[" + jobId +"]");
					break;
			}
        }

		disp("main function: finish...");
	}
    
	static void disp(String msg) {
		System.out.println(msg);
	}

}
