# Copyright 2021 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


# [START composer_gkeoperator_airflow_1]


from airflow import models
from airflow.operators.bash_operator import BashOperator
from airflow.providers.google.cloud.operators.kubernetes_engine import (
    GKECreateClusterOperator,
    GKEDeleteClusterOperator,
    GKEStartPodOperator,
)
from airflow.utils.dates import days_ago

with models.DAG(
    "s3batch_gkeminipod",
    schedule_interval=None,  # Override to match your needs
    start_date=days_ago(1),
    tags=["s3batch"],
) as dag:

    # [START composer_gke_create_cluster_airflow_1]
    # [START composer_gkeoperator_minconfig_airflow_1]
    # [START composer_gkeoperator_templateconfig_airflow_1]
    # [START composer_gkeoperator_affinity_airflow_1]
    # [START composer_gkeoperator_fullconfig_airflow_1]
    # TODO(developer): update with your values
    PROJECT_ID = "wqgcpprj"
    CLUSTER_ZONE = "asia-northeast1-a"
    CLUSTER_NAME = "s3batch-cluster"
    # [END composer_gkeoperator_minconfig_airflow_1]
    # [END composer_gkeoperator_templateconfig_airflow_1]
    # [END composer_gkeoperator_affinity_airflow_1]
    # [END composer_gkeoperator_fullconfig_airflow_1]
    CLUSTER = {"name": CLUSTER_NAME, "initial_node_count": 1}
    # [END composer_gke_create_cluster_airflow_1]

    # [START composer_gkeoperator_minconfig_airflow_1]
    def crtGkePodOperator(jobId):
        return GKEStartPodOperator(
        task_id=jobId,
        name=jobId,
        project_id=PROJECT_ID,
        location=CLUSTER_ZONE,
        cluster_name=CLUSTER_NAME,
        cmds=['java'],
        arguments=['-jar', 's3batch.jar', jobId],
        namespace='default',
        image='gcr.io/wqgcpprj/s3batch:latest')
    
    # [END composer_gkeoperator_minconfig_airflow_1]

    # [START composer_gke_create_cluster_airflow_1]
    create_cluster = GKECreateClusterOperator(
        task_id="create_cluster",
        project_id=PROJECT_ID,
        location=CLUSTER_ZONE,
        body=CLUSTER,
    )
    # Using the BashOperator to create node pools is a workaround
    # In Airflow 2, because of https://github.com/apache/airflow/pull/17820
    # Node pool creation can be done using the GKECreateClusterOperator

    create_node_pools = BashOperator(
        task_id="create_node_pools",
        bash_command=f"gcloud container node-pools create pool-0 \
                        --cluster={CLUSTER_NAME} \
                        --num-nodes=1 \
                        --zone={CLUSTER_ZONE} \
                        && gcloud container node-pools create pool-1 \
                        --cluster={CLUSTER_NAME} \
                        --num-nodes=1 \
                        --zone={CLUSTER_ZONE}",
    )
    # [END composer_gke_create_cluster_airflow_1]

    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc150d = crtGkePodOperator('semc150d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc151d = crtGkePodOperator('semc151d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc152d = crtGkePodOperator('semc152d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc160d = crtGkePodOperator('semc160d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc161d = crtGkePodOperator('semc161d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc170d = crtGkePodOperator('semc170d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc171d = crtGkePodOperator('semc171d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]

    # [START composer_gkeoperator_delete_cluster_airflow_1]
    delete_cluster = GKEDeleteClusterOperator(
        task_id="delete_cluster",
        name=CLUSTER_NAME,
        project_id=PROJECT_ID,
        location=CLUSTER_ZONE,
    )
    # [END composer_gkeoperator_delete_cluster_airflow_1]

    create_cluster >> create_node_pools >> semc150d >> semc151d >> semc152d >> semc160d >> semc161d >> semc170d >> semc171d >> delete_cluster

# [END composer_gkeoperator_airflow_1]
