#　nice-meet.py
def nice_meet():
    import logging
    logging.info('Nice to meet you!!!')
    print ('Nice to meet you!!!')
