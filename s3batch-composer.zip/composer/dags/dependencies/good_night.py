#　good-night.py
import requests
import json    
def good_night(task_id):
    import logging
    logging.info('Task Id:[' + task_id + '],Good Night before rec_log!!!')
    print ('Good Night before rec_log!!!' )
    rec_log("Task Id:[" + task_id + "],From Good Night Task of GCP Composer(weiqiao-composer)")
    logging.info('Good Night after rec_log!!!')
    print ('Good Night after rec_log!!!' )
def good_nightx():
    good_night('good_night_x' )
def good_nighty():
    good_night('good_night_y' )
def rec_log(msg):
    import logging
    logging.info('rec_log begin!!!')
    print ('rec_log begin!!!' )
    res = requests.put(
        "https://weiqiao-gae-cloudsql-dot-innate-harbor-331911.an.r.appspot.com/putlog",
        json.dumps({'key':'weiqiao-composer-goodnith-task', 'log': msg}),
        headers={'Content-Type': 'application/json'})
    logging.info('rec_log end!!!')
    print ('rec_log end!!!' )
    return "OK"
