# Copyright 2018 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""An example DAG demonstrating Kubernetes Pod Operator."""

# [START composer_kubernetespodoperator_airflow_1]
import datetime

from airflow import models
from airflow.contrib.kubernetes import secret
from airflow.contrib.operators import kubernetes_pod_operator


# A Secret is an object that contains a small amount of sensitive data such as
# a password, a token, or a key. Such information might otherwise be put in a
# Pod specification or in an image; putting it in a Secret object allows for
# more control over how it is used, and reduces the risk of accidental
# exposure.

# [START composer_kubernetespodoperator_secretobject_airflow_1]
secret_env = secret.Secret(
    # Expose the secret as environment variable.
    deploy_type='env',
    # The name of the environment variable, since deploy_type is `env` rather
    # than `volume`.
    deploy_target='SQL_CONN',
    # Name of the Kubernetes Secret
    secret='airflow-secrets',
    # Key of a secret stored in this Secret object
    key='sql_alchemy_conn')
secret_volume = secret.Secret(
    deploy_type='volume',
    # Path where we mount the secret as volume
    deploy_target='/var/secrets/google',
    # Name of Kubernetes Secret
    secret='service-account',
    # Key in the form of service account file name
    key='service-account.json')
# [END composer_kubernetespodoperator_secretobject_airflow_1]

# If you are running Airflow in more than one time zone
# see https://airflow.apache.org/docs/apache-airflow/stable/timezone.html
# for best practices
YESTERDAY = datetime.datetime.now() - datetime.timedelta(days=1)

# [START composer_kubernetespodoperator_minconfig_airflow_1]
def crtK8sPodOperator(jobId):
    return kubernetes_pod_operator.KubernetesPodOperator(
        task_id=jobId,
        name=jobId,
        cmds=['java'],
        arguments=['-jar', 's3batch.jar', jobId],
        namespace='default',
        image='gcr.io/wqgcpprj/s3batch:latest')
# [END composer_kubernetespodoperator_minconfig_airflow_1]

# If a Pod fails to launch, or has an error occur in the container, Airflow
# will show the task as failed, as well as contain all of the task logs
# required to debug.
with models.DAG(
        dag_id='s3batch_k8sminipod',
        schedule_interval=datetime.timedelta(days=1),
        start_date=YESTERDAY) as dag:
    # Only name, namespace, image, and task_id are required to create a
    # KubernetesPodOperator. In Cloud Composer, currently the operator defaults
    # to using the config file found at `/home/airflow/composer_kube_config if
    # no `config_file` parameter is specified. By default it will contain the
    # credentials for Cloud Composer's Google Kubernetes Engine cluster that is
    # created upon environment creation.
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc150d = crtK8sPodOperator('semc150d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc151d = crtK8sPodOperator('semc151d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc152d = crtK8sPodOperator('semc152d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc160d = crtK8sPodOperator('semc160d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc161d = crtK8sPodOperator('semc161d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc170d = crtK8sPodOperator('semc170d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc171d = crtK8sPodOperator('semc171d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    semc150d >> semc151d >> semc152d >> semc160d >> semc161d >> semc170d >> semc171d
# [END composer_kubernetespodoperator_airflow_1]
