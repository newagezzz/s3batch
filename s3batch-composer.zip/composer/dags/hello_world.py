#sample.py

from __future__ import print_function

import datetime
from airflow import models
from airflow.operators import bash_operator
from airflow.operators import python_operator

default_dag_args = {
    'start_date': datetime.datetime(2021, 11, 19),
}

with models.DAG(
        'hello_world',
        schedule_interval=datetime.timedelta(days=1),
        default_args=default_dag_args) as dag:
    def greeting():
        import logging
        logging.info('Hello World!')

    hellox_python = python_operator.PythonOperator(
        task_id='hellox',
        python_callable=greeting)

    helloy_python = python_operator.PythonOperator(
        task_id='helloy',
        python_callable=greeting)

    hellox_python >> helloy_python
