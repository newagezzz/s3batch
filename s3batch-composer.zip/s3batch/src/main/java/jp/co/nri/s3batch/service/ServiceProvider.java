package jp.co.nri.s3batch.service;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServiceProvider {

    @Bean
    public Semc150dService getSemc150d() {
        System.out.println("ServiceProvider#getSemc150d()");
        return new Semc150dService("Semc150d service");
    }
    @Bean
    public Semc151dService getSemc151d() {
        System.out.println("ServiceProvider#getSemc151d()");
        return new Semc151dService("Semc151d service");
    }
    @Bean
    public Semc152dService getSemc152d() {
        System.out.println("ServiceProvider#getSemc152d()");
        return new Semc152dService("Semc152d service");
    }
    @Bean
    public Semc153dService getSemc153d() {
        System.out.println("ServiceProvider#getSemc153d()");
        return new Semc153dService("Semc153d service");
    }
    public static Semc170dService getSemc170d() {
        System.out.println("ServiceProvider#getSemc170d()");
        return new Semc170dService("Semc170d service");
    }
    public static Semc171dService getSemc171d() {
        System.out.println("ServiceProvider#getSemc171d()");
        return new Semc171dService("Semc171d service");
    }
}
