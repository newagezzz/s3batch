package jp.co.nri.s3batch.service;

import org.springframework.stereotype.Service;

@Service
public class Semc161dService extends BatchService {

    public Semc161dService() {
        super("###Semc161d service###");
    }
    public void startProc() {
        disp("Semc161dService started...name:[" + name + "]");
        disp("Semc161dService finished...name:[" + name + "]");
    }

}
