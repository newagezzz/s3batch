package jp.co.nri.s3batch.service;

public class Semc150dService extends BatchService {

    public Semc150dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc150dService started...name:[" + name + "]");
        disp("Semc150dService finished...name:[" + name + "]");
    }

}
