package jp.co.nri.s3batch.service;

import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter;

abstract public class BatchService {

    protected String name;
    public BatchService(String name) {
        this.name = name;
    }
    abstract public void startProc();

	void disp(String msg) {
        // 現在日時を取得
        LocalDateTime nowDate = LocalDateTime.now();
		System.out.println(nowDate + ":[" + msg + "]");
	}

    @Override
    public String toString() {
        return "BatchService [name=" + name + "]";
    }
}
