package jp.co.nri.s3batch.service;

public class Semc152dService extends BatchService {

    public Semc152dService() {
        super("###Semc152d service###");
    }
    public Semc152dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc152dService started...name:[" + name + "]");
        disp("Semc152dService finished...name:[" + name + "]");
    }

}
