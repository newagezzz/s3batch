package jp.co.nri.s3batch.service;

public class Semc171dService extends BatchService {

    public Semc171dService() {
        super("###Semc171d service###");
    }
    public Semc171dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc171dService started...name:[" + name + "]");
        disp("Semc171dService finished...name:[" + name + "]");
    }

}
