package jp.co.nri.s3batch.service;

import org.springframework.stereotype.Component;

@Component
public class Semc160dService extends BatchService {

    public Semc160dService() {
        super("###Semc160d service###");
    }
    public void startProc() {
        disp("Semc160dService started...name:[" + name + "]");
        disp("Semc160dService finished...name:[" + name + "]");
    }

}
