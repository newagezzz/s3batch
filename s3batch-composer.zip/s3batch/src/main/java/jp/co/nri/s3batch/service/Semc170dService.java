package jp.co.nri.s3batch.service;

public class Semc170dService extends BatchService {

    public Semc170dService() {
        super("###Semc170d service###");
    }
    public Semc170dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc170dService started...name:[" + name + "]");
        disp("Semc170dService finished...name:[" + name + "]");
    }

}
