package jp.co.nri.s3batch.service;

public class Semc153dService extends BatchService {

    public Semc153dService() {
        super("###Semc153d service###");
    }
    public Semc153dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc153dService started...name:[" + name + "]");
        disp("Semc153dService finished...name:[" + name + "]");
    }

}
