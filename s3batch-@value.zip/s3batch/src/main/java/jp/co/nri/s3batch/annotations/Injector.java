package jp.co.nri.s3batch.annotations;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Injector {
    public static void inject(Object instance) {
        Field[] fields = instance.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (field.isAnnotationPresent(AddressValue.class)) {
                AddressValue av = field.getAnnotation(AddressValue.class);
                field.setAccessible(true); // should work on private fields
                try {
                    field.set(instance, av.value());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
