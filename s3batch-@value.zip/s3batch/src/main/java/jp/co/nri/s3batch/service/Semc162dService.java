package jp.co.nri.s3batch.service;

import org.springframework.stereotype.Component;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.charset.Charset;
import jp.co.nri.s3batch.annotations.*;
import org.springframework.core.io.Resource;
import org.springframework.util.StreamUtils;
import org.springframework.beans.factory.annotation.Value;
import java.io.InputStream;

@S3Annotation
@Component
public class Semc162dService extends BatchService {

    @S3Value("Weiqiao Zhang")  //custom annotation
    String nameBCA;   //name by custom annotation

    @S3Value2(58)  //custom annotation
    int ageBCA;   //age by custom annotation

    @AddressValue("aaaaaaaa")
    private String address1;

    @AddressValue("bbbbbbbbbbb")
    private String address2;

    @AddressValue("ccccccccccccccccc")
    private String address3;

    @Value("/home/airflow/gcs/data/test_file")
    private String mntFileName;

    @Value("${FIO-SYS010}")
	private String sys010;

    @Value("${FIO-SYS020}")
	private String sys020;

    /*
    @Value("${SIO-SYS030}")
	private Resource sys030;
    */
    @Value("${SIO-SYS030}")
    InputStream sys030InputStream;

    public Semc162dService() {
        super("###Semc162d service###");
    }
    public Semc162dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc162dService started...name:[" + name + "]");
        disp("Field value set by custom annotations,nameBCA:[" + nameBCA + "],ageBCA:[" + ageBCA + "]");
        disp("Field value set by custom annotations,address1:[" + address1 + "],address2:[" + address2 + "],address3:[" + address3 + "]");
        disp("InputStream Object returned by Custom @Value:[" + sys030InputStream + "]");
        try {
            // InputStream by Custom @Value
            disp("↓↓↓↓↓↓↓↓↓↓↓InputStream by Custom @Value↓↓↓↓↓↓↓↓↓↓↓↓");
            disp("11111");
            Charset chrSet = Charset.defaultCharset();
            disp("22222");
            String str = StreamUtils.copyToString(sys030InputStream, chrSet);
            disp("33333");
            disp("InputStream by Custom @Value:[" + str + "]\n");
            disp("44444");
            disp("↑↑↑↑↑↑↑↑↑↑↑InputStream by Custom @Value↑↑↑↑↑↑↑↑↑↑↑");

            // ファイルのエンコーディングを指定する場合(Charset)
            /*
            Path file = Paths.get("d:\\work\\temp\\good1.txt");
            disp("file information:[" + file.toString() + "]");
            String text = Files.readString(file, Charset.forName("MS932"));
            disp(file.toString() + ":[" + text + "]");
            */
            Person person = new Person("soufiane", "cheouati", "34");
            ObjectToJsonConverter serializer = new ObjectToJsonConverter();
            String jsonString = serializer.convertToJson(person);
            System.out.println("JsonString:[" + jsonString + "]");
        } catch (Exception ex) {
            disp("Exceptions occurred:[" + ex + "]");
        }
        disp("Semc162dService finished...name:[" + name + "]");
    }
}
