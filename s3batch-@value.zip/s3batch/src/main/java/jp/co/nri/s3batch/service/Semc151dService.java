package jp.co.nri.s3batch.service;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.charset.Charset;
import jp.co.nri.s3batch.annotations.S3Value;
import jp.co.nri.s3batch.annotations.S3Value2;
import jp.co.nri.s3batch.annotations.Person;
import jp.co.nri.s3batch.annotations.ObjectToJsonConverter;

public class Semc151dService extends BatchService {

    @S3Value("Weiqiao Zhang")  //custom annotation
    String nameBCA;   //name by custom annotation

    @S3Value2(58)  //custom annotation
    int ageBCA;   //age by custom annotation

    public Semc151dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc151dService started...name:[" + name + "]");
        disp("Field value set by custom annotations,nameBCA:[" + nameBCA + "],ageBCA:[" + ageBCA + "]");
        try {
            // ファイルのエンコーディングを指定する場合(Charset)
            /*
            Path file = Paths.get("d:\\work\\temp\\good1.txt");
            disp("file information:[" + file.toString() + "]");
            String text = Files.readString(file, Charset.forName("MS932"));
            disp(file.toString() + ":[" + text + "]");
            */
            Person person = new Person("soufiane", "cheouati", "34");
            ObjectToJsonConverter serializer = new ObjectToJsonConverter();
            String jsonString = serializer.convertToJson(person);
            System.out.println("JsonString:[" + jsonString + "]");
        } catch (Exception ex) {
            disp("Exceptions occurred:[" + ex + "]");
        }
        disp("Semc151dService finished...name:[" + name + "]");
    }
}
