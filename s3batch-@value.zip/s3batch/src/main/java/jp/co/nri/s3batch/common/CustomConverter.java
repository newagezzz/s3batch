package jp.co.nri.s3batch.common;

import org.springframework.core.convert.converter.GenericConverter;
import org.springframework.stereotype.Component;
import java.io.UnsupportedEncodingException;
import org.springframework.core.convert.TypeDescriptor;
import java.util.*;
import com.google.protobuf.ByteString;
import org.springframework.core.convert.support.DefaultConversionService;

@Component
public class CustomConverter implements GenericConverter {
    @Override
    public Set<ConvertiblePair> getConvertibleTypes() {
        return Collections.singleton(new ConvertiblePair(ByteString.class, String.class));
    }

    @Override
    public Object convert(Object source, TypeDescriptor sourceType,
                          TypeDescriptor targetType) {
        if (sourceType.getType() == String.class) {
            return source;
        }
        try {
            source = ((ByteString) source).toString("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return source;
    }
}
