package jp.co.nri.s3batch.common;

import org.springframework.stereotype.Component;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.lang.reflect.Proxy;
import java.lang.reflect.Field;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.BeansException;
import jp.co.nri.s3batch.annotations.AddressValue;
import jp.co.nri.s3batch.annotations.S3Value;
import jp.co.nri.s3batch.annotations.S3Value2;
import jp.co.nri.s3batch.annotations.S3Annotation;

@Component
public class S3BeanPostProcessor implements BeanPostProcessor {

    // Container to store all the beans annotation with @S3Value
    Map<String, Class<?>> s3BeanMap = new HashMap();

    // Step in processing used before all the different proxies wrap around spring beans.
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        if (bean.getClass().isAnnotationPresent(S3Annotation.class)) {
            s3BeanMap.put(beanName, bean.getClass());
        }
        return bean;            
    }

    // Step in processing all the different proxies wrap around spring beans.
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        /*
        Class<?> beanClass = s3BeanMap.get(beanName);
        if (beanClass != null) {
            return Proxy.newProxyInstance(
                beanClass.getClassLoader(),
                beanClass.getInterfaces(),
                (proxy, method, args) -> {
                    long start = System.currentTimeMillis();
                    Object invoke = method.invoke(bean, args);
                    long end = System.currentTimeMillis();
                    long duration = end - start;
                    System.out.println("Duration of method invocation:[" + method.getName() + "] was :[" + duration + "]");
                    return invoke;
                }
            );
        }       
        */
        inject(bean);
        return bean;
    }
    void inject(Object instance) {
        Field[] fields = instance.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (field.isAnnotationPresent(AddressValue.class)) {
                AddressValue av = field.getAnnotation(AddressValue.class);
                field.setAccessible(true); // should work on private fields
                try {
                    field.set(instance, av.value());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (field.isAnnotationPresent(S3Value.class)) {
                S3Value sv = field.getAnnotation(S3Value.class);
                field.setAccessible(true); // should work on private fields
                try {
                    field.set(instance, sv.value());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (field.isAnnotationPresent(S3Value2.class)) {
                S3Value2 sv2 = field.getAnnotation(S3Value2.class);
                field.setAccessible(true); // should work on private fields
                try {
                    field.set(instance, sv2.value());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
