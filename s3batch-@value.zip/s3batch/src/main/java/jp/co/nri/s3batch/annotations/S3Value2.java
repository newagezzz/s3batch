package jp.co.nri.s3batch.annotations;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;

@Target(FIELD) // Decorate the properties of the class 
@Retention(RUNTIME)
@Documented
public @interface S3Value2 {
    int value() default 0; // Assign a value to the age 
}
