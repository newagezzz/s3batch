package jp.co.nri.s3batch.service;

import org.springframework.stereotype.Component;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.charset.Charset;
import jp.co.nri.s3batch.annotations.*;

@Component
public class Semc163dService extends BatchService {

    @S3Value("Yinzhi Zhang")  //custom annotation
    String nameBCA;   //name by custom annotation

    @S3Value2(22)  //custom annotation
    int ageBCA;   //age by custom annotation

    public Semc163dService() {
        super("###Semc163d service###");
    }
    public Semc163dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc163dService started...name:[" + name + "]");
        try {
            // ファイルのエンコーディングを指定する場合(Charset)
            /*
            Path file = Paths.get("d:\\work\\temp\\good1.txt");
            disp("file information:[" + file.toString() + "]");
            String text = Files.readString(file, Charset.forName("MS932"));
            disp(file.toString() + ":[" + text + "]");
            */
            Person person = new Person("soufiane", "cheouati", "34");
            ObjectToJsonConverter serializer = new ObjectToJsonConverter();
            String jsonString = serializer.convertToJson(person);
            System.out.println("JsonString:[" + jsonString + "]");
        } catch (Exception ex) {
            disp("Exceptions occurred:[" + ex + "]");
        }
        disp("Semc163dService finished...name:[" + name + "]");
    }
}
