package jp.co.nri.s3batch;

import jp.co.nri.s3batch.annotations.*;

public class O2JTest {

	public static void main(String[] args) {
        try {
            Person person = new Person("soufiane", "cheouati", "34");
            ObjectToJsonConverter serializer = new ObjectToJsonConverter();
            String jsonString = serializer.convertToJson(person);
            System.out.println("JsonString:[" + jsonString + "]");
        } catch (Exception ex) {
            System.out.println("Error occurred:[" + ex + "]");
        }
        //ClassPathXmlApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");
    }
}
