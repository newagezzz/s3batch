package jp.co.nri.s3batch.service;

import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Date;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cloud.gcp.secretmanager.SecretManagerTemplate;
import org.springframework.core.env.Environment;

public class Semc153dService extends BatchService {

    public Semc153dService() {
        super("###Semc153d service###");
    }
    public Semc153dService(String name) {
        super(name);
    }

	@Autowired
	private Environment environment;

	//@Autowired
	//private SecretManagerTemplate secretManagerTemplate;

	// Application secrets can be accessed using @Value and using the "sm://" syntax.
	@Value("sm://my-db-password")
	private String appSecret1;

	@Value("${sm://my-db-password}")
	private String appSecret2;

	// Multiple ways of loading the application-secret are demonstrated in bootstrap.properties.
	// Try it with my-app-secret-1 or my-app-secret-2
	@Value("${my-app-secret-1}")
	private String myAppSecret;

	@Value("sm://my-db-password")
	private Resource rescSecret;

    public void startProc() {
        disp("Semc153dService started...name:[" + name + "]");

		disp("↓↓↓↓↓↓↓↓↓↓↓Contents of Secret Manager↓↓↓↓↓↓↓↓↓↓↓↓");
		disp("sm://my-db-password:[" + appSecret1 +"]");
		disp("${sm://my-db-password}:[" + appSecret2 +"]");
		disp("${my-app-secret-1}:[" + myAppSecret +"]");
		disp("↑↑↑↑↑↑↑↑↑↑↑Contents of Secret Manager↑↑↑↑↑↑↑↑↑↑↑");
        InputStream inpStrm;
        Charset chrSet;
        String str;
        try {
			// SecretManagerResource
			disp("↓↓↓↓↓↓↓↓↓↓↓Secret Manager Resource↓↓↓↓↓↓↓↓↓↓↓↓");
			disp("00000");
			inpStrm = rescSecret.getInputStream();
			disp("11111");
			chrSet = Charset.defaultCharset();
			disp("22222");
			str = StreamUtils.copyToString(inpStrm, chrSet);
			disp("33333");
			disp("SecretResource:[" + str + "]\n");
			disp("44444");
			disp("↑↑↑↑↑↑↑↑↑↑↑SecretManagerResource↑↑↑↑↑↑↑↑↑↑↑");
        } catch (Exception ex) {
           disp("Semc153dService retrieve secret throught resource failed.Exception:[" + ex + "]");
        }
/*
		String version = "1";
		String secretId = "my-db-password";
		String projectId = "weiqiaoprj";
		if (StringUtils.isEmpty(version)) {
			version = SecretManagerTemplate.LATEST_VERSION;
		}

		String secretPayload;
		if (StringUtils.isEmpty(projectId)) {
			secretPayload = this.secretManagerTemplate.getSecretString(
					"sm://" + secretId + "/" + version);
		}
		else {
			secretPayload = this.secretManagerTemplate.getSecretString(
					"sm://" + projectId + "/" + secretId + "/" + version);
		}
		disp("↓↓↓↓↓↓↓↓↓↓↓Contents of Secret Manager↓↓↓↓↓↓↓↓↓↓↓↓");
		disp("secretPayload:[" + secretPayload +"]");
		disp("↑↑↑↑↑↑↑↑↑↑↑Contents of Secret Manager↑↑↑↑↑↑↑↑↑↑↑");
*/
        try {
            // mntfile
            File MntFIle = new File("/home/airflow/gcs/data/test_file");
            String msg = MntFIle.exists() ? "the MntFile is ready" : "the MntFile is not exist";
            disp("↓↓↓↓↓↓↓↓↓↓↓mnt file↓↓↓↓↓↓↓↓↓↓↓↓");
            disp(msg);
            disp("↑↑↑↑↑↑↑↑↑↑↑mnt file↑↑↑↑↑↑↑↑↑↑↑");
        } catch (Exception ex) {
           disp("Semc161dService failed.Exception:[" + ex + "]");
        }
        disp("Semc153dService finished...name:[" + name + "]");
    }
}
