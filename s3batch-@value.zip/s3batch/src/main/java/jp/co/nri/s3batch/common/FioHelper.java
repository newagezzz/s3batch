package jp.co.nri.s3batch.common;

import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.*;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import org.springframework.core.io.Resource;
import org.springframework.core.io.WritableResource;
import org.springframework.core.io.FileUrlResource;
import org.springframework.core.io.UrlResource;
import org.springframework.util.StreamUtils;
import org.springframework.context.ConfigurableApplicationContext;

public class FioHelper {
    public String fioName;
    public String fioUrl;
    public String fioAccess;
    public Stream fioStream;
    public String fioStatus;
    Resource rescFile;
    WritableResource outputResc;
    public InputStream inStrm;
    public OutputStream outStrm;

    public FioHelper() {
        //do nothing
    }
    public FioHelper(ConfigurableApplicationContext ctx, String pName, String pUrl, String pAccess) {
        fioName = pName;
        fioUrl = pUrl;
        fioAccess = pAccess;
        try {
            rescFile = ctx.getResource(fioUrl);
            //disp("Contents of [" + fioUrl + "][" + StreamUtils.copyToString(rescFile.getInputStream(), Charset.defaultCharset()) + "]");
            switch(fioAccess) {
                case "RO":
                    inStrm = rescFile.getInputStream();
                    fioStatus = "OK";
                    break;
                case "WO":
                    outputResc =  (WritableResource)rescFile;
                    outStrm = outputResc.getOutputStream();
                    fioStatus = "OK";
                    break;
                default:
                    fioStatus = "NG:{Invalid access mode:[" + fioName + "],[" + fioUrl + "][" + fioAccess + "]}";
                    disp("Invalid access mode:[" + fioName + "],[" + fioUrl + "][" + fioAccess + "]");
                    break;
            }
        } catch (IOException ex) {
            fioStatus = "NG:{Exception[" + ex + "] occurred while access resource:[" + fioName + "],[" + fioUrl + "][" + fioAccess + "]}";
            disp("Exception[" + ex + "] occurred while access resource:[" + fioName + "],[" + fioUrl + "][" + fioAccess + "]");
        }
    }
	protected static void disp(String msg) {
        // 現在日時を取得
        LocalDateTime nowDate = LocalDateTime.now();
		System.out.println(nowDate + ":[" + msg + "]");
	}
}
