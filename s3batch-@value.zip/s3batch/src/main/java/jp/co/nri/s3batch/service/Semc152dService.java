package jp.co.nri.s3batch.service;

import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Date;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.util.StreamUtils;

public class Semc152dService extends BatchService {

    @Value("file:/home/airflow/gcs/data/test_file")
    private Resource mntFile;

    @Value("gs://newage-test-bucket/hello.txt")
    private Resource gcsFile;

    public Semc152dService() {
        super("###Semc152d service###");
    }
    public Semc152dService(String name) {
        super(name);
    }
    public void startProc() {
        InputStream inpStrm;
        Charset chrSet;
        String str;
        disp("Semc152dService started...name:[" + name + "]");
        try {
            // gcsFile
            disp("↓↓↓↓↓↓↓↓↓↓↓gcs file↓↓↓↓↓↓↓↓↓↓↓↓");
            disp("00000");
            inpStrm = gcsFile.getInputStream();
            disp("11111");
            chrSet = Charset.defaultCharset();
            disp("22222");
            str = StreamUtils.copyToString(inpStrm, chrSet);
            disp("33333");
            disp("gcsFile:" + str + "\n");
            disp("44444");
            disp("↑↑↑↑↑↑↑↑↑↑↑gcs file↑↑↑↑↑↑↑↑↑↑↑");
            // mntFile
            disp("↓↓↓↓↓↓↓↓↓↓↓mnt file↓↓↓↓↓↓↓↓↓↓↓↓");
            disp("aaaa");
            inpStrm = mntFile.getInputStream();
            disp("bbbb");
            chrSet = Charset.defaultCharset();
            disp("cccc");
            str = StreamUtils.copyToString(inpStrm, chrSet);
            disp("dddd");
            disp("mntFile:" + str + "\n");
            disp("eeee");
            disp("↑↑↑↑↑↑↑↑↑↑↑mnt file↑↑↑↑↑↑↑↑↑↑↑");

        } catch (IOException ex) {
           disp("Semc152dService failed.Exception:[" + ex + "]");
        }
        disp("Semc152dService finished...name:[" + name + "]");
    }
}
