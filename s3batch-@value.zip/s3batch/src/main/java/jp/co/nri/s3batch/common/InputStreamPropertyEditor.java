package jp.co.nri.s3batch.common;

import java.beans.PropertyEditorSupport;
import java.nio.file.Paths;
import org.springframework.core.io.UrlResource;
import org.springframework.core.io.Resource;
import java.io.InputStream;

public class InputStreamPropertyEditor extends PropertyEditorSupport{

    @Override
    public void setAsText(String text) throws IllegalArgumentException {
        try {
            System.out.println("InputStreamPropertyEditor,text:[" + text + "]");
            if (text == null) {
                this.setValue(null);
            } else {
                Resource urlResource = new UrlResource(text);
                InputStream inpStrm = urlResource.getInputStream();
                this.setValue(inpStrm);
            }
        } catch (Exception ex) {
            System.out.println("InputStreamPropertyEditor, Error occurred:[" + ex + "]");
            this.setValue(null);
        }
    }
}
