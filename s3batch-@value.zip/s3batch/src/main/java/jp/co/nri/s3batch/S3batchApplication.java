package jp.co.nri.s3batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import java.util.*;
import jp.co.nri.s3batch.service.*;
import jp.co.nri.s3batch.common.BatchCommon;
import jp.co.nri.s3batch.common.CustomConverter;
import org.springframework.core.convert.support.DefaultConversionService;

@SpringBootApplication
public class S3batchApplication extends BatchCommon{

	public static void main(String[] args) {
		BatchService bs;
  	    String jobId, sysCmd, rootDir;
		Boolean validJobFlg;  
		disp("main function: start...");
		switch(args.length) {
			case 0:
				jobId = "NO-JOB-DESIGNATED";
				sysCmd = "";
				rootDir = "/";
				break;
			case 1:
				jobId = args[0].toUpperCase();
				sysCmd = "";
				rootDir = "/";
				break;
			case 2:
				jobId = args[0].toUpperCase();
				sysCmd = args[1];
				rootDir = "/";
				break;
			default:
				jobId = args[0].toUpperCase();
				sysCmd = args[1];
				rootDir = args[2];
				break;
		}
		disp("job id:[" + jobId + "]...env-var:[" + System.getenv() + "]");
		if (sysCmd.length() > 0) {
			doCommand(sysCmd);
		}
	    getAllPaths(rootDir);
		validJobFlg = true;
		//For Secret Manager Error fixing.....
		//((DefaultConversionService)DefaultConversionService.getSharedInstance()).addConverter(new CustomConverter());
		//ClassPathXmlApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");

        try (ConfigurableApplicationContext ctx = SpringApplication.run(S3batchApplication.class, args)) {
			switch(jobId) {
				case "SEMC150D":
					bs = ctx.getBean(Semc150dService.class);
					break;
				case "SEMC151D":
					bs = ctx.getBean(Semc151dService.class);
					break;
				case "SEMC152D":
					bs = ctx.getBean(Semc152dService.class);
					break;
				case "SEMC153D":
					bs = ctx.getBean(Semc153dService.class);
					break;
				case "SEMC160D":
					bs = ctx.getBean(Semc160dService.class);
					break;
				case "SEMC161D":
					bs = ctx.getBean(Semc161dService.class);
					break;
				case "SEMC162D":
					bs = ctx.getBean(Semc162dService.class);
					break;
				case "SEMC163D":
					bs = ctx.getBean(Semc163dService.class);
					break;
				case "SEMC170D":
					//bs = ctx.getBean(Semc170dService.class);
					bs = ServiceProvider.getSemc170d();
					break;
				case "SEMC171D":
					//bs = ctx.getBean(Semc171dService.class);
					bs = ServiceProvider.getSemc171d();
					break;
				default:
					disp("Invalid Job-Id:[" + jobId +"]");
					validJobFlg = false;
					bs = null;
					break;
			}
			if (validJobFlg) {
				bs.setupIOProc(ctx, System.getenv());
				bs.startProc();
			}
        }
		disp("main function: finish...");
	}
}
